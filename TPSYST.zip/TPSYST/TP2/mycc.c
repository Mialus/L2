#include<stdio.h> 
#include<stdlib.h>
#include<string.h>

int main(int argc, char** argv){
int i;

	for(i=0;i<argc;i++){
		 if(strcmp("-h",argv[i]){

			printf("Usage: mycc [-h] [-c] [-o output] [files...]");
}
 		if(strcmp("-c",argv[i]){

}
		if(strcmp("-o",argv[i]){

}	



}
}
