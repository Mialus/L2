#include"lcg.h"
#include<stdio.h> 
#include<stdlib.h>

void lcg_seed(struct lcg *self, int n);
	*self.xn=n;
}
