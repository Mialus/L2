#include<stdio.h> 
#include<stdlib.h>

int lcg_next(struct lcg *self);

return((self->a*self->xn+self->c)%self->m);

}
