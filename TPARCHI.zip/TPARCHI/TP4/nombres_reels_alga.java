public class nombres_reels_algo{
	static int getSigne(float reel){
		return ( Float.floatToIntBits(reel)>>>31);
	}
	static int getExposant(float reel){
		
	}
	static int getMantisse(float reel){
		
	}
	static float setSigne(float reel,int signe){
		
	}
	static float setExposant(float reel,int exposant){
		
	}
	static float setMantisse(float reel,int mantisse){
		
	}
	static String toHexString(float reel){
		
	}
	static float parseFloat(String chaine){
		
	}
	static float maximum(){
		
	}
	public static void main( String[] args ) {	
		
		float f=0;
		System.out.println("Test get...");
		System.out.println("getSigne(125.25f)         ="+getSigne(125.25f));
		System.out.println("getMantisse(125.25f)     ="+Integer.toHexString(getMantisse(125.25f)));
		System.out.println("getExposant(125.25f)     ="+getExposant(125.25f));
		System.out.println("Test set...");
		f=setSigne(f,0); f=setExposant(f,6); f=setMantisse(f,0xFA8000);
		System.out.println("125.25=" +f);
		System.out.println("Test toHexString et parseFloat");
		System.out.println("Float.toHexString(125.25f)      ="+Float.toHexString(+125.25f));
		System.out.println("toHexString(125.25f)      ="+toHexString(+125.25f));
		System.out.println("Float.toHexString(-0.375f)      ="+Float.toHexString(-0.375f));
		System.out.println("toHexString(-0.375f)      ="+toHexString(-0.375f));
		System.out.println("Float.parseFloat(+0x1.f5p6)    ="+Float.parseFloat("+0x1.f5p6"));
		System.out.println("parseFloat(+0x1.f5p6)    ="+parseFloat("+0x1.f5p6"));
		System.out.println("Float.parseFloat(-0x1.8p-2)    ="+Float.parseFloat("-0x1.8p-2"));
		System.out.println("parseFloat(-0x1.8p-2)    ="+parseFloat("-0x1.8p-2"));
		System.out.println("Test Maximum");		
		System.out.println("Maximum      ="+Float.toHexString(maximum()));
	}
} 

