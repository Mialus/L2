public class Groupe{
 int nbr;
Personne [] tab = new Personne[5];
}