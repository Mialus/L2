#!/bin/sh
ETC_PASSWD=~/TPSYST/projet/etc/passwd
ETC_SHADOW=~/TPSYST/projet/etc/shadow
ETC_GROUP=~/TPSYST/projet/etc/group

stty -echo
read -p "Password: " P
stty echo
echo
echo "Your password is: $P"
echo $P | md5sum -t

