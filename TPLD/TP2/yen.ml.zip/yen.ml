type prix = Euro of int
| Yen of int